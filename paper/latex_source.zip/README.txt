MitoSync v72 LaTeX source, 2026-11-03

From paper/isbi, run:
pdflatex main_isbi.tex
bibtex main_isbi
pdflatex main_isbi.tex
pdflatex main_isbi.tex

Includes the existing ISBI template, bibliography and figure assets.
The bundled .bbl permits compilation without a new bibliography pass.
No data, weights, human answers or credentials are included.
